# Lab21 — bằng chứng loss mask và trạng thái thí nghiệm

**Họ tên:** Đinh Hoàng Đức · **MSSV:** 2A202602795

**Ngày thực nghiệm local:** 08/10/2026 · **Phạm vi:** NB1, chạy thật trên CPU; chuẩn bị NB2–NB5.

**Trạng thái:** chưa phải bài nộp đầy đủ. NB2–NB5 chưa chạy vì chưa có runtime CUDA.

## 1. Thiết lập và nguồn bằng chứng

Thực nghiệm dùng tokenizer thật của `unsloth/Qwen3.5-4B`, giữ nguyên base model mặc định của tier T4 để bằng chứng áp dụng cho model dự kiến dùng trong lab. T4 ở đây là tên cấu hình; phần cứng thực thi NB1 là CPU trong WSL2, không tải trọng số model và không chạy huấn luyện. Corpus là bộ ticket CSKH tiếng Việt đi kèm repo, với đầu ra JSON gồm `intent`, `urgency`, `product`, `sentiment`. Đây là corpus seed của lab, không phải dữ liệu khách hàng thu thập thực tế; các số đo trong report là kết quả thực thi trên corpus này.

| Thuộc tính | Kết quả thực tế | Bằng chứng |
|---|---|---|
| Base model | `unsloth/Qwen3.5-4B` | [nb1_run.json](../results/nb1_run.json) |
| Corpus | 250 mẫu | [token_stats.json](../results/token_stats.json) |
| Train / validation | 225 / 25, seed 42 | [nb1_run.json](../results/nb1_run.json) |
| Python | 3.12.3 | [nb1_run.json](../results/nb1_run.json) |
| Transformers / Tokenizers / Jinja2 | 5.19.0 / 0.23.2 / 3.1.6 | [nb1_run.json](../results/nb1_run.json) |
| Loss mask | `assistant-only` | [mask_proof.json](../results/mask_proof.json) |
| Render dùng cho mask | `enable_thinking=False` | [mask_proof.json](../results/mask_proof.json) |
| `max_length` thực dùng trong NB1 | 256 | [token_stats.json](../results/token_stats.json) |
| Thời gian NB1 | 28,098 giây | [nb1_run.json](../results/nb1_run.json) |

Lần chạy mới hoàn tất lúc **00:25:25 ngày 08/10/2026, giờ Việt Nam**. Thời gian trên đo từ đầu script NB1 đến lúc ghi metadata, gồm nạp tokenizer, tính thống kê, kiểm tra mask toàn corpus và tạo split; không gồm cài dependencies, lần thử trước đó hay script so TRL. Report ghi thời gian đo được, không lấy mốc khoảng 25 giây trong đề bài làm kết quả. Lần chạy cũ được giữ riêng trong `submission/evidence/nb1`; số liệu hiện tại dùng `results/`.

Tokenizer được tải từ snapshot `3764fa359b9082ea5a1e4a5e3ac3aaf6e9671636`. SHA-256 chat template: `8452ca85cb1e0ff04304c02f417a53305d5ba17f6eb9d5693343ad8355f985a8`. SHA-256 corpus và hai file split được lưu trong `nb1_run.json` để đối chiếu lần chạy.

## 2. Chuỗi sau template và phần thực sự được tính loss

Mẫu đầu tiên sau `apply_chat_template`, với `enable_thinking=False`:

```text
<|im_start|>system
Phân loại ticket sau.<|im_end|>
<|im_start|>user
Alo shop, mình đặt balo laptop mã đơn VN411453. Cho tôi trả lại. Đã 3 ngày rồi. Cho tôi hỏi.<|im_end|>
<|im_start|>assistant
<think>

</think>

{"intent": "doi_tra", "urgency": "trung_binh", "product": "balo laptop", "sentiment": "trung_tinh"}<|im_end|>
```

Giải mã ngược đúng các vị trí `labels != -100`:

```text
{"intent": "doi_tra", "urgency": "trung_binh", "product": "balo laptop", "sentiment": "trung_tinh"}<|im_end|>
```

Chuỗi loss có một ký tự xuống dòng sau `<|im_end|>`; bản đầy đủ nằm trong trường `supervised_text`. Nội dung được giám sát khớp toàn bộ JSON trả lời, cộng token kết thúc lượt và xuống dòng của template. Token kết thúc được giữ để model học dừng. Các thẻ role, system prompt, câu hỏi và khối thinking rỗng ở generation prompt đều bị mask. “Đúng bằng câu trả lời” ở đây nghĩa là nội dung câu trả lời cùng phần kết thúc lượt, không phải chỉ một đoạn đầu của JSON.

| Kiểm tra trên mẫu đầu | Kết quả |
|---|---|
| Tổng token | 94 |
| Token được giám sát | 37 |
| Token bị mask | 57 |
| `supervised_fraction` | **0.3936**, thấp hơn 0.95 |
| `answer_is_supervised` | **true** |
| `question_is_masked` | **true** |
| `supervised_equals_rendered_answer_tail` | **true** |

Hai assert bắt buộc đều xanh. Kiểm tra câu trả lời dùng **toàn bộ output**, không chỉ 40 ký tự đầu. Các vị trí được giám sát là chỉ số **57–93**, tính từ 0; `input_ids` và `labels` được lưu trong [mask_proof.json](../results/mask_proof.json), nên có thể kiểm tra trực tiếp phép giải mã.

Đã kiểm tra **250/250 mẫu** với cùng cấu hình. Mỗi mẫu đều chứa toàn bộ câu trả lời trong loss, không chứa câu hỏi, khớp chính xác đuôi assistant sau generation prompt, và có `0 < supervised_fraction < 0.95`. Tỷ lệ giám sát từng mẫu nằm trong khoảng **0.376344–0.437500**. Toàn corpus có **23.266 token**, trong đó **9.506 token** được giám sát. Bằng chứng từng mẫu nằm trong [corpus_mask_check.json](../results/corpus_mask_check.json).

Đối chứng `everything` trên cùng mẫu giám sát **94/94 token, tức 100%**, và đoạn giải mã chứa cả câu hỏi. Đối chứng này cho thấy ngưỡng 0.95 phát hiện lỗi tính loss trên prompt. Chế độ được chọn cho NB1 là `assistant-only`.

## 3. Template có giữ `<think>` không?

**Có, trong ca kiểm tra của NB1.** [template_check.json](../results/template_check.json) ghi `ok=true`, `open_tag_present=true`, `body_present=true`. Nội dung kiểm tra vẫn xuất hiện sau render:

```text
<|im_start|>user
2+2?<|im_end|>
<|im_start|>assistant
<think>
buoc 1: kiem tra. buoc 2: tra loi.
</think>

4<|im_end|>
```

Phép kiểm tra này dùng chế độ thinking mặc định của template và một lượt assistant chứa trace. Kết quả chứng minh trace được giữ trong ca đó; không suy rộng thành bảo đảm cho mọi hội thoại nhiều lượt. Corpus ticket có câu trả lời JSON thuần, nên phần chứng minh mask dùng `enable_thinking=False`. Template vẫn render khối thinking rỗng, nhưng đặt nó trong generation prompt và mask toàn bộ khối này.

Lần thử ban đầu với thinking mặc định cho thấy `</think>` còn nằm trong đoạn loss. Bằng chứng được giữ ở [nb1_initial_attempt.log](evidence/nb1/nb1_initial_attempt.log). Đây là lý do chọn cấu hình render tường minh cho lần chạy cuối, thay vì kết luận mask đúng chỉ vì JSON có mặt trong loss.

## 4. Đặt `max_length` từ số đo

Độ dài được đo trên cả 250 hội thoại **sau chat template**, gồm system, user, assistant và special tokens, với cùng `enable_thinking=False` như phần chứng minh mask. Phép đo lấy số phần tử trong `input_ids`, không truncation trước khi tính percentile.

| Thống kê | Token |
|---|---|
| Trung bình | 93.1 |
| p50 | 93 |
| p95 | **98** |
| p99 | 100 |
| Lớn nhất | 101 |
| `suggested_max_length` / `selected_max_length` | **256 / 256** |
| Mẫu có độ dài vượt 256 | **0** |

Nguồn: [token_stats.json](../results/token_stats.json). Percentile dùng nearest-rank: với 250 mẫu, p95 là phần tử thứ 238 trong danh sách độ dài đã sắp xếp. Hàm của lab làm tròn lên lũy thừa 2 và có mức tối thiểu 256; do đó p95=98 cho kết quả 256, thay vì phép làm tròn trực tiếp lên 128.

Tier T4 mặc định đặt 1024, nhưng NB1 đã **thực sự dùng 256** để xây mask và kiểm tra corpus. Vì độ dài lớn nhất chỉ là 101, lựa chọn này giữ toàn bộ câu trả lời và token kết thúc ở tất cả mẫu. Thực nghiệm không đo hiệu năng train hay VRAM nên không quy đổi việc giảm trần độ dài thành mức tiết kiệm bộ nhớ thực tế.

## 5. So mask với hai đường TRL

Đã chạy `python scripts/check_mask_agreement.py` với **TRL 1.14.2**, trước mọi huấn luyện. Output đầy đủ ở [mask_agreement.log](../results/mask_agreement.log). Script dùng cặp hỏi–đáp ngắn riêng và thinking mặc định; số token của nó không phải số token mẫu ticket trong phần 2.

| Đường kiểm tra | Kết quả thực tế |
|---|---|
| Mask lab trên mẫu của script | 11/31 token, gồm `</think>`, JSON và kết thúc lượt |
| Tokenizer với `return_assistant_tokens_mask=True` | **0/31 token**; cảnh báo thiếu `{% generation %}` |
| Hàm `get_training_chat_template` mà `SFTTrainer` dùng | **ValueError**: template không tương thích huấn luyện |
| Exit code của script | **1 — FAIL** |

Template Unsloth hiện tại không có generation markers, nên lấy trực tiếp `assistant_masks` sẽ tạo batch không có token được giám sát. Đường trainer báo lỗi thay vì âm thầm sử dụng mask đó. Phép kiểm tra trainer ở đây thực thi hàm xử lý template của TRL; không khởi tạo model hay thực hiện một bước `SFTTrainer`.

Không thể khẳng định mask TRL tương đương mask lab. Khi train, dùng dữ liệu đã tokenize bằng `labkit.data.to_training_dataset`, giữ nguyên `input_ids` và `labels` đã chứng minh, với `max_length=256`, `mask_mode="assistant-only"`, **`enable_thinking=False`**, và không packing. NB3/NB4 đã được sửa để đọc recipe từ artefact NB1, kiểm tra model ID, SHA template và token IDs/labels mẫu proof trước khi tiếp tục. Nếu đổi base model, phải chạy lại NB1 và script so mask cho model mới.

Kiểm tra thật trên **225 mẫu train** tái hiện lỗi cũ: **225/225 mẫu** dùng mặc định thinking tạo dữ liệu khác recipe NB1. Sau sửa, tất cả khớp toàn bộ đuôi câu trả lời, không chứa câu hỏi, không mất mẫu. Dataset train có **20.951 token**, **8.564 token** được giám sát, tỷ lệ **0.40876330485418355**. Bằng chứng: [training_mask_validation.json](../results/training_mask_validation.json). Đây là kiểm tra tokenizer/dataset trên CPU, **chưa phải bằng chứng batch SFTTrainer**. Code NB3/NB4 có gate kiểm tra labels toàn dataset và batch collator trước `.train()`, sẽ lưu bằng chứng riêng khi thực thi GPU. Chưa có các file batch proof ở lần chạy này.

## 6. Tái chạy và kiểm tra

Từ thư mục repo, trong môi trường Python đã cài dependencies CPU:

```bash
export COMPUTE_TIER=T4
unset BASE_MODEL
.venv/bin/python notebooks/01_data_and_mask.py
.venv/bin/python scripts/check_mask_agreement.py
.venv/bin/python -m pytest tests
```

Để kiểm tra thêm hàm template của TRL trong môi trường CPU, cần cài `trl` và `datasets`; lần đo này dùng lần lượt 1.14.2 và 5.1.0. Script so mask hiện dự kiến trả mã 1 với template trên, và mã này phải được đọc cùng output thay vì đổi thành PASS.

Log NB1 thành công: [nb1_console.log](../results/nb1_console.log). Split cố định: [train.jsonl](../data/split/train.jsonl), [val.jsonl](../data/split/val.jsonl). Bộ test nguyên bản chạy bằng Python Windows trả **123 passed, 3 skipped**; đây là kiểm tra phần mềm, tách biệt với lần NB1 chạy tokenizer thật trong WSL. Notebook Colab đã được sinh lại từ nguồn Python. File tests và tập eval không được sửa.

## 7. Kết luận và điều học được

NB1 hoàn thành mục tiêu chứng minh vùng loss trên corpus đã chọn: nội dung được giám sát khớp đầy đủ câu trả lời JSON, giữ token kết thúc lượt, và loại toàn bộ prompt. Kết luận dựa trên phép giải mã labels, hai assert bắt buộc và kiểm tra từng mẫu trong toàn corpus. Tỷ lệ giám sát 0.3936 ở mẫu đầu, cùng khoảng tỷ lệ của 250 mẫu, cho thấy đây không phải chế độ tính loss trên mọi token. Tuy nhiên, chỉ nhìn tỷ lệ thấp chưa đủ: lần thử ban đầu vẫn giám sát phần đóng thinking dù câu trả lời có mặt. Vì vậy phép so khớp chính xác đuôi assistant và khai báo `enable_thinking` là phần cần thiết của bằng chứng.

Qua thực nghiệm này, tôi rút ra rằng tên cờ `assistant-only` không tự bảo đảm vùng loss đúng với ý định huấn luyện. Chat template quyết định generation prompt kết thúc ở đâu, và cùng một model có thể cho vùng loss khác khi thay chế độ thinking. Tôi cũng thấy cần kiểm tra dạng dữ liệu trả về khi đo token: độ dài dictionary không phải độ dài chuỗi token. Số đo p95 chỉ có ý nghĩa khi lấy từ đúng hội thoại đã render và đúng cấu hình tạo labels. Cuối cùng, mask lab pass nhưng kiểm tra tương thích TRL fail là hai kết quả có thể cùng đúng. Bước tiếp theo cần dùng labels đã chứng minh và kiểm tra batch thực tế trước khi train; chưa có cơ sở kết luận fine-tuning cải thiện chất lượng, latency hay khả năng triển khai.

## 8. Phần cứng và đường chạy Colab

Máy được đo có **i5-1135G7, 4 core/8 luồng**, RAM **16.852.832.256 byte**, GPU **Intel Iris Xe**. Driver báo AdapterRAM **1.073.741.824 byte**; đây không phải VRAM CUDA. Máy không có NVIDIA GPU để thực thi đường train/QLoRA của repo. Bằng chứng: [local_hardware.json](../results/local_hardware.json). Python Windows và WSL hiện không có PyTorch; môi trường WSL đủ chạy tokenizer thật của NB1. Giữ model 4B và chuyển phần train sang T4 thay vì trộn bằng chứng mask từ model khác.

Colab đã mở qua Chrome DevTools MCP nhưng Google từ chối đăng nhập trong trình duyệt tự động. Phần GPU chưa bắt đầu. Đã chuẩn bị notebook local `colab/Lab21_RUN_ALL.ipynb` và gói `submission/lab21_colab_code.zip`, chứa đúng sửa đổi local chưa push. Chạy bằng Chrome/Edge thường đã đăng nhập Google, full eval và EPOCHS=2; hướng dẫn: [RUN-FULL-COLAB.md](../docs/RUN-FULL-COLAB.md). Gói code có manifest checksum, không chứa credentials, cache, môi trường Python hay metrics GPU giả.

## 9. NB2 — mốc đóng băng, chưa đo

Chưa có `baselines_frozen.json`; chưa có số đo chứng minh **(b) > (a)**. Giữ nguyên prompt đơn giản (a), prompt tối ưu + few-shot (b), cùng base model và cùng tập eval. Few-shot bổ sung của repo lấy từ train, không từ eval hoặc holdout. Tôi chọn corpus seed vì có nhãn từng trường và scorer khách quan; chưa thử dataset khác sau khi xem kết quả.

NB2 sẽ đánh giá đầy đủ **50 mẫu target và 15 mẫu regression**. Chỉ đóng băng khi full eval và (b) thắng (a). NB3/NB4 đã có gate kiểm tra model, checksum eval, SHA prompt và mốc đóng băng trước khi tải model để train. Không lấy điểm trong tài liệu mô phỏng hoặc số đo T4 của giảng viên làm kết quả cá nhân. Baseline (c) sẽ đo sau khi adapter được train thật.

## 10. Bốn run và bốn nhóm — chưa có số đo GPU

| Run | Cấu hình hoặc biến đổi dự kiến | Trạng thái |
|---|---|---|
| correct | Text decoder linear; r=16, alpha=32, LR=1e-4 | Chưa train |
| attn_only | Chỉ q,v; rank tính bằng matched_rank trên model thật | Chưa train |
| wrong_lr | Chỉ LR đổi thành 1e-5 | Chưa train |
| qlora | Chỉ chuyển base sang 4-bit | Chưa train |

Đây là cấu hình dự kiến, không phải số đo. Chưa xác nhận matched rank, ngân sách tham số, layer_types, loss, VRAM hay actual_steps. T4 có batch hiệu dụng 16; bốn run dùng cùng step budget từ EPOCHS=2, và so actual_steps sau train. NB3 sẽ in/lưu layer_types của model nạp thật. Không so q,v r=16 với text-linear r=16 để suy luận về vị trí.

| Nhóm | Đo bằng | Kết quả hiện có |
|---|---|---|
| target | Accuracy từng trường so nhãn | Chưa đo |
| regression | Keyword recall câu hỏi phổ thông | Chưa đo |
| format | JSON parse và đủ bốn khóa | Chưa đo |
| latency | ms/mẫu, greedy decode | Chưa đo |

NB5 sẽ xếp bốn adapter bằng target trong `autopsy.json`; `final_loss` chỉ là loss train. Code lưu dự đoán đầy đủ và score của baseline (b) cho từng ticket, gắn nhãn thắng/hòa/thua bằng chênh lệch thực tế. Cần ít nhất năm ví dụ, gồm hai ca fine-tune thua. Hiện chưa có output model nên không tạo ví dụ định tính giả. Regression của các contrast không được đo trong autopsy mặc định; cổng bốn nhóm áp dụng cho correct so với baseline đóng băng.

## 11. Phán quyết và phần còn thiếu trước nộp

**Chưa đủ bằng chứng kết luận fine-tune PASS hay FAIL.** NB1 PASS không thay thế NB5. Chưa tạo verdict, runs.csv hay baseline giả để lấp phần thiếu. Điều cụ thể học thêm là một file token_stats ghi 256 không có tác dụng nếu train vẫn truyền 1024 hoặc quên thinking=False. Phải đưa số đo vào recipe thực tế và kiểm tra tiếp batch mà trainer sử dụng. Chứng minh tokenizer và chứng minh collator là hai lớp kiểm tra riêng; tests xanh cũng không chứng minh thí nghiệm GPU đã chạy.

Sau khi có ZIP kết quả GPU, phải điền kết quả so sánh, diễn giải verdict, chọn ví dụ thắng/thua có thật và cập nhật phản tư theo lỗi model thực sự mắc. Nếu target tốt nhưng regression giảm, phải giữ kết luận FAIL và phân tích nguyên nhân, không làm yếu baseline hoặc sửa eval. Chạy `make verify` hoặc `python scripts/verify.py` nguyên bản trước nộp. Hiện còn thiếu baseline đóng băng, runs.csv, verdict.json và autopsy.json.
